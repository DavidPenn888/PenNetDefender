package com.pennet.defender;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PenNetDefenderApplicationTests {

    @Test
    void contextLoads() {
    }

}
