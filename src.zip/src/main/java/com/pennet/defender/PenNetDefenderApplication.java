package com.pennet.defender;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PenNetDefenderApplication {

    public static void main(String[] args) {
        SpringApplication.run(PenNetDefenderApplication.class, args);
    }

}
