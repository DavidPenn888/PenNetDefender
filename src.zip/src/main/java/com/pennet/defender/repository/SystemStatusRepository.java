package com.pennet.defender.repository;

import com.pennet.defender.model.SystemStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface SystemStatusRepository extends JpaRepository<SystemStatus, Integer> {
    List<SystemStatus> findTop24ByTimestampBetweenOrderByTimestampDesc(LocalDateTime start, LocalDateTime end);
}